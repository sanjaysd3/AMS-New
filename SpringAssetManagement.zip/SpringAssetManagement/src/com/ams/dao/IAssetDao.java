package com.ams.dao;

import java.util.ArrayList;

import com.ams.bean.Asset;
import com.ams.bean.Request;
import com.ams.bean.UserMaster;

public interface IAssetDao {

	public int addAsset(Asset asset);
	public int raiseRequest(Request request);
	public ArrayList<Request> getList();
	public UserMaster login(UserMaster user);
	public ArrayList<Asset> getAssetList();
	public Asset getAssetDetail(int assetId);
	public int updateAsset(Asset asset);
	public void allocateRequest(int requestId, int quantity, int assetId);
}
